/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package co.edu.ucatolica.mineriaDatos;

/**
 *
 * @author MaRu
 */
public class Direcciones1 {
    String Usaquen = "https://www.google.com.co/maps/place/Usaqu%C3%A9n,+Bogot%C3%A1/@4.744984,-74.0988382,12z/data=!3m1!4b1!4m5!3m4!1s0x8e3f8f805d4e5beb:0x853611c42477c6f!8m2!3d4.695458!4d-74.031194";
    String Chapinero = "https://www.google.com.co/maps/place/Chapinero,+Bogot%C3%A1/@4.6335067,-74.0894499,13z/data=!4m5!3m4!1s0x8e3f909e88bf0583:0xcee402e0b005bc73!8m2!3d4.649656!4d-74.063097";
    String SantaFe = "https://www.google.com.co/maps/place/Santa+F%C3%A9,+Bogot%C3%A1/@4.5929776,-74.0756777,13z/data=!3m1!4b1!4m5!3m4!1s0x8e3f9a24f5244f69:0xc863309eb6922ea1!8m2!3d4.611238!4d-74.070245";
    String SanCristobal = "https://www.google.com.co/maps/place/San+Crist%C3%B3bal,+Bogot%C3%A1/@4.5489797,-74.1015476,13z/data=!3m1!4b1!4m5!3m4!1s0x8e3f988caf2631c9:0x39057bb472804cc8!8m2!3d4.5591989!4d-74.091471";
    String Usme = "https://www.google.com.co/maps/place/Usme,+Bogot%C3%A1/@4.5029527,-74.1302871,13z/data=!3m1!4b1!4m5!3m4!1s0x8e3fa3f96481dab7:0xa43270a0bc7ba2e0!8m2!3d4.506367!4d-74.107952";
    String Tunjueito = "https://www.google.com.co/maps/place/Tunjuelito,+Bogot%C3%A1/@4.5637027,-74.1733846,13z/data=!3m1!4b1!4m5!3m4!1s0x8e3f9f56e7f0212b:0xabe1e0880322be94!8m2!3d4.569067!4d-74.134573";
    String Bosa = "https://www.google.com.co/maps/place/Bosa,+Bogot%C3%A1/@4.6256413,-74.2051251,14z/data=!3m1!4b1!4m5!3m4!1s0x8e3f9e6fec7428e9:0x46c5252ef4b8d101!8m2!3d4.609896!4d-74.184721";
    String CiudadKennedy = "https://www.google.com.co/maps/place/Kennedy,+Bogot%C3%A1/@4.6299446,-74.1868976,13z/data=!3m1!4b1!4m5!3m4!1s0x8e3f9c20c1186379:0x72c48cbe21e275ac!8m2!3d4.63113!4d-74.148473";
    String Fontibon = "https://www.google.com.co/maps/place/Fontib%C3%B3n,+Bogot%C3%A1/@4.6775246,-74.1747026,13z/data=!3m1!4b1!4m5!3m4!1s0x8e3f9c5fa5d2a31d:0xa5f9c78731920c46!8m2!3d4.673689!4d-74.143671";
    String Engativa = "https://www.google.com.co/maps/place/Engativ%C3%A1,+Bogot%C3%A1/@4.6971531,-74.1536806,13z/data=!3m1!4b1!4m5!3m4!1s0x8e3f9ca931bb3685:0x777bc49f16df0ff4!8m2!3d4.70846!4d-74.11168";
    String Suba = "https://www.google.com.co/maps/place/Suba,+Bogot%C3%A1/@4.761433,-74.1530332,12z/data=!3m1!4b1!4m5!3m4!1s0x8e3f84509d700417:0xc7cd69e940f94f14!8m2!3d4.740881!4d-74.08381";
    String BarriosUnidos = "https://www.google.com.co/maps/place/Barrios+Unidos,+Bogot%C3%A1/@4.6697582,-74.0928956,14z/data=!3m1!4b1!4m5!3m4!1s0x8e3f9afe484261e9:0xf6b262f63cd9e822!8m2!3d4.664752!4d-74.075214";
    String Teusaquillo = "https://www.google.com.co/maps/place/Teusaquillo,+Bogot%C3%A1/@4.6408003,-74.1050016,14z/data=!3m1!4b1!4m5!3m4!1s0x8e3f9beaa5647337:0x6fa358372e109359!8m2!3d4.6358097!4d-74.079448";
    String LosMartires = "https://www.google.com.co/maps/place/Los+M%C3%A1rtires,+Bogot%C3%A1/@4.6084197,-74.1074731,14z/data=!3m1!4b1!4m5!3m4!1s0x8e3f996fc1731b19:0x67d539e568f514ca!8m2!3d4.604824!4d-74.085503";
    String AntonioNarino = "https://www.google.com.co/maps/place/Antonio+Nari%C3%B1o,+Bogot%C3%A1/@4.5872223,-74.1257532,14z/data=!3m1!4b1!4m5!3m4!1s0x8e3f9ec938288ccd:0xd26fbabad84b817!8m2!3d4.589684!4d-74.094058";
    String PuenteAranda = "https://www.google.com.co/maps/place/Puente+Aranda,+Bogot%C3%A1/@4.6194713,-74.1279636,14z/data=!3m1!4b1!4m5!3m4!1s0x8e3f995af262b5b5:0x9fbf40b4e087e0e0!8m2!3d4.614995!4d-74.114656";
    String Candelaria = "https://www.google.com.co/maps/place/La+Candelaria,+Bogot%C3%A1/@4.5963989,-74.0797888,15z/data=!3m1!4b1!4m5!3m4!1s0x8e3f99a844cf79cb:0xa58d1864daa71331!8m2!3d4.597014!4d-74.0728759";
    String RafaelUribe = "https://www.google.com.co/maps/place/Rafael+Uribe,+Bogot%C3%A1/@4.5660612,-74.1301561,14z/data=!3m1!4b1!4m5!3m4!1s0x8e3f98b78f49de33:0xd61bc7317575ff64!8m2!3d4.578436!4d-74.110488";
    String CiudadBolivar = "https://www.google.com.co/maps/place/Cdad.+Bol%C3%ADvar,+Bogot%C3%A1/@4.5344802,-74.2239862,12z/data=!3m1!4b1!4m5!3m4!1s0x8e3fa1eeb33e606f:0xac63ff9e839d40a!8m2!3d4.579524!4d-74.1574289";
    String Sumapaz = "https://www.google.com.co/maps/place/Sumapaz,+Cabrera,+Cundinamarca/@3.8666838,-74.486809,12z/data=!4m5!3m4!1s0x8e3e9271fa38a41f:0x99cf7e1f2036f54e!8m2!3d3.86667!4d-74.41667";
}
